package entity;

public class StoreKeeper {
    private String name;

    public StoreKeeper(){

    }

    public StoreKeeper(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
